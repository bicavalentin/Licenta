<?php

require_once(__DIR__.'/../utils/db_connector.php');

class UserTable
{
    private static ?UserTable $instance = null;

    private $conn;

    private function __construct()
    {
        $this->conn = DatabaseConnection::getInstance()->getConnection();
    }

    public static function getInstance()
    {
        if(!self::$instance)
            self::$instance = new UserTable();
        return self::$instance;
    }

    public function getQueryErrors(){
        return $this->conn->error;
    }

    public function addUser($user){
        $sql= "INSERT INTO users(`name`,`email`,`password`,`role_id`)
        VALUES('$user->name','$user->email', '$user->password','$user->role_id')";
    
        $this->conn->query($sql);





        
    }

    public function updateUser($id, $user){
        $sql ="UPDATE users SET `name` = '$user->name', 
                                `email` =  '$user->email',
                                `password` =  '$user->password'
                                WHERE `id`= '$id'";
        
        $this->conn->query($sql);
    }

    public function deleteUser($id){
        $sql = "DELETE FROM users where `id` = '$id'";
        $this->conn->query($sql);
    }

    public function getAllUsers(){
        $sql = "SELECT * FROM `users` INNER JOIN `roles` ON `users`.`role_id` = `roles`.`id`";
        return $this->conn->query($sql);
    }

    public function getUsersByRole($role_id){
        $sql = "SELECT * FROM `users` INNER JOIN `roles` ON `users`.`role_id` = `roles`.`id`  WHERE `roles`.`id` = '$role_id'";
        return $this->conn->query($sql);
    }

    public function getUserByEmail($email){
        $sql = "SELECT * FROM `users` INNER JOIN `roles` ON `users`.`role_id` = `roles`.`id`  WHERE `users`.`email` = '$email'";
        return $this->conn->query($sql);
    }

    public function getUserById($user_id){
        $sql = "SELECT * FROM `users` INNER JOIN `roles` ON `users`.`role_id` = `roles`.`id`  WHERE `users`.`id` = '$user_id'";
        return $this->conn->query($sql);
    }
    
}