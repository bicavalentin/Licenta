<?php

require_once(__DIR__.'/../utils/db_connector.php');

class CartTable
{
    private static ?CartTable $instance = null;

    private $conn;

    private function __construct()
    {
        $this->conn = DatabaseConnection::getInstance()->getConnection();
    }

    public static function getInstance()
    {
        if(!self::$instance)
            self::$instance = new CartTable();
        return self::$instance;
    }

    public function getQueryErrors(){
        return $this->conn->error;
    }

    public function addToCart($cart){
        $sql= "INSERT INTO cart(`user_id`,`product_id`,`bought_quantity`, `price`,`status`)
                VALUES('$cart->user_id','$cart->product_id', '$cart->bought_quantity','$cart->status')";
    
        $this->conn->query($sql);
    }

    public function updateCartProduct($id,$cart){
        $sql ="UPDATE cart SET `product_id` = '$cart->product_id', 
                                `user_id` =  '$cart->user_id',
                                `bought_quantity` =  '$cart->bought_quantity',
                                `price` =  '$cart->price',
                                `status` =  'pending'
                                WHERE `id`= '$id'";
        
        $this->conn->query($sql);
    }

    public function removeFromCart($id){
        $sql = "DELETE FROM cart where `id` = '$id'";
        $this->conn->query($sql);
    }

    public function getAllItemsFromCart($user_id){
        $sql = "SELECT * FROM `cart` 
                        INNER JOIN `users` ON `cart`.`user_id` = `users`.`id`
                        INNER JOIN `product_details` ON `cart`.`product_id` = `product_details`.`product_id`
                        INNER JOIN `product` ON `cart`.`product_id` = `product`.`product_id`
                        WHERE `users.id` = '$user_id'";
        return $this->conn->query($sql);
    }

    public function confirmOrder($user_id){
        $sql ="UPDATE cart SET `status` =  'confirmed' WHERE `user_id`= '$user_id'";
        $this->conn->query($sql);
        // to update product quantity
    }   

    public function cancelOrder($user_id){
        $sql ="UPDATE cart SET `status` =  'canceled' WHERE `user_id`= '$user_id'";
        $this->conn->query($sql);
        // to update product quantity
    }   
}