<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once "./tables/tables.php";
require_once "./mappers/RoleMapper.php";

$roles =
[
    [
        'name' => "admin"
    ],
    [
        'name' => "user"
    ],
];
// echo "<br>index<br>";
// var_dump(1);
// die;
echo "adding roles";
foreach ($roles as $key => $value) {
    $role = RoleMapper::map($value);
    $tables["roles_table"]->addRole($role);
}

// echo "get all roles";
// echo "<br>";
// echo "<pre>";
// foreach ($tables["roles_table"]->getAllRoles()->fetch_all(MYSQLI_ASSOC) as $key => $value) {
//     $role = RoleMapper::map($value);
//     echo $role->id. "-" .$role->name ;
//     echo "<br>";
// }


// echo "delete all roles";
// echo "<br>";
// echo "<pre>";
// foreach ($tables["roles_table"]->getAllRoles()->fetch_all(MYSQLI_ASSOC) as $key => $value) {
//     $role = RoleMapper::map($value);
//     $tables["roles_table"]->deleteRole($role->id);
// }



// echo "get all roles";
// echo "<br>";
// echo "<pre>";
// foreach ($tables["roles_table"]->getAllRoles()->fetch_all(MYSQLI_ASSOC) as $key => $value) {
//     $role = RoleMapper::map($value);
//     echo $role->id. "-" .$role->name ;
//     echo "<br>";
// }

