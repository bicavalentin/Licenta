<div class="footer">
    <div class="container">
        <div class="row">
            <div class="foooter-col1">
                <h3>Descarca Aplicatiile</h3>
                <p>Descarca aplicatia pentru Iphone sau Android de aici</p>
                <div class="app-logo">
                    <img src="imagini/app-store.png">
                    <img src="imagini/play-store.png">
                </div>
            </div>

            <div class="footer-col2">

                <p><br>Ne propuem sa fim sustenabili si sa aducem beneficii cat mai multe</p>
            </div>
            <div class="foooter-col3">
                <h3>Linkuri utile</h3>
                <ul>
                    <li>Cupoane</li>
                    <li>Bloguri</li>
                    <li>Retur</li>
                    <li>Afiliati</li>
                </ul>
            </div>
            <div class="foooter-col4">
                <h3>Urmariti-ne</h3>
                <ul>
                    <li>Facebook</li>
                    <li>Twitter</li>
                    <li>Instagram</li>
                    <li>YouTube</li>
                </ul>
            </div>
        </div>
    </div>
</div>