<?php

require_once(__DIR__."/../models/User.php");

class UserMapper{
    public static function map($data){
        $user = new User();
        $user->id = $data['id'] ?? null;
        $user->name = $data['name'];
        $user->email = $data['email'];
        $user->password = $data['password'];
        $user->role_id = $data['role_id'] ?? 2;
        return $user;
    }
}







