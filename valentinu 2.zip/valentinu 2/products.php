<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="Style.css">
    <title>Toate Produsele</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

</head>

<body>

    <?php
    require_once "./header.php";
    ?>

    <!------ produse----->

    <div class="small-container">

        <div class="row row-2">
            <h2>Toate Produsele</h2>
            <select>
                <option>Default Shorting</option>
                <option>Short by price</option>
                <option>Short by popularity</option>
                <option>Short by sale</option>

            </select>
        </div>
        <div class="row">
            <div class="col4">
                <img src="imagini/descărcare.jfif" alt="">
                <h4>Tricou Rosu Deschis</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>


                </div>
                <p>$40.00</p>
            </div>
            <div class="col4">
                <img src="imagini/nike.jpg" alt="">
                <h4>Adidas Nike</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>


                </div>
                <p>$40.00</p>
            </div>
            <div class="col4">
                <img src="imagini/Pantaloni.jfif" alt="">
                <h4>Pantaloni Scurti</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>


                </div>
                <p>$40.00</p>
            </div>
            <div class="col4">
                <img src="imagini/sapca.jfif" alt="">
                <h4>Sapca</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>


                </div>
                <p>$40.00</p>
            </div>
            <div class="row">
                <div class="col4">
                    <img src="imagini/poza8.jfif" alt="">
                    <h4>Geaca Primavara </h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>


                    </div>
                    <p>$40.00</p>
                </div>
                <div class="col4">
                    <img src="imagini/poza9.jfif" alt="">
                    <h4>Moto style</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>


                    </div>
                    <p>$40.00</p>
                </div>
                <div class="col4">
                    <img src="imagini/poza11.jfif" alt="">
                    <h4>Geaca rosie</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>


                    </div>
                    <p>$40.00</p>
                </div>
                <div class="col4">
                    <img src="imagini/poza12.jfif" alt="">
                    <h4>Geaca Fosforescenta</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>


                    </div>
                    <p>$40.00</p>
                </div>
                <div class="row">
                    <div class="col4">
                        <img src="imagini/poza13.jfif" alt="">
                        <h4>Ceas</h4>
                        <div class="rating">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>


                        </div>
                        <p>$40.00</p>
                    </div>
                    <div class="col4">
                        <img src="imagini/poza14.jfif" alt="">
                        <h4>Ceas</h4>
                        <div class="rating">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>


                        </div>
                        <p>$40.00</p>
                    </div>
                    <div class="col4">
                        <img src="imagini/poza15.jfif" alt="">
                        <h4>Ceas</h4>
                        <div class="rating">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>


                        </div>
                        <p>$40.00</p>
                    </div>
                    <div class="col4">
                        <img src="imagini/poza16.jfif" alt="">
                        <h4>Ceas </h4>
                        <div class="rating">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>


                        </div>
                        <p>$40.00</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col4">
                    <img src="imagini/descărcare.jfif" alt="">
                    <h4>Tricou Rosu Deschis</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>


                    </div>
                    <p>$40.00</p>
                </div>
                <div class="col4">
                    <img src="imagini/nike.jpg" alt="">
                    <h4>Adidas Nike</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>


                    </div>
                    <p>$40.00</p>
                </div>
                <div class="col4">
                    <img src="imagini/Pantaloni.jfif" alt="">
                    <h4>Pantaloni Scurti</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>


                    </div>
                    <p>$40.00</p>
                </div>
                <div class="col4">
                    <img src="imagini/sapca.jfif" alt="">
                    <h4>Sapca</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>


                    </div>
                    <p>$40.00</p>


                </div>

                <div class="page-btn">
                    <span>1</span>
                    <span>2</span>
                    <span>3</span>
                    <span>4</span>
                    <span>&#8594;</span>
                </div>

            </div>

        </div>

    </div>

                <?php
                require_once "./footer.php";
                ?>
                <!-----js for toggle menu------>

                <script>
                    var MenuItems = document.getElementById("MenuItems");
                    MenuItems.style.maxHeight = "0px";

                    function menutoggle() {
                        if (MenuItems.style.maxHeight = "0px") {
                            MenuItems.style.maxHeight = "200px";
                        } else {
                            MenuItems.style.maxHeight = "0px";
                        }
                    }
                </script>

</body>

</html>