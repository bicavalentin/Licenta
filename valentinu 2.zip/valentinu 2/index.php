<?php
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="Style.css">
    <title>Cumparaturi Online</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

</head>

<body>
    <div class="header">
        <div class="container">
            <?php
            require_once "./header.php";
            ?>

            <div class="row">
                <div class="col2">
                    <h1>Uita de griji si fa-ti cumparaturile <br>online alaturi de Emag si Carrefour</h1>
                    <p>Uita de griji Uita de griji Uita de griji Uita <br>de griji Uita de griji Uit Uita de griji </p>
                    <a href="./products.php" class="btn">Exploreaza acum</a>
                </div>
                <div class="col2">
                    <img src="imagini/image1.png">
                </div>
            </div>
        </div>
    </div>

    <!------ produse----->

    <div class="small-container">
        <h2 class="title">Articole Recomandate</h2>
        <div class="row">
            <div class="col4">
                <img src="imagini/descărcare.jfif" alt="">
                <h4>Tricou Rosu Deschis</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>


                </div>
                <p>$40.00</p>
            </div>
            <div class="col4">
                <img src="imagini/nike.jpg" alt="">
                <h4>Adidas Nike</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>


                </div>
                <p>$40.00</p>
            </div>
            <div class="col4">
                <img src="imagini/Pantaloni.jfif" alt="">
                <h4>Pantaloni Scurti</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>


                </div>
                <p>$40.00</p>
            </div>
            <div class="col4">
                <img src="imagini/sapca.jfif" alt="">
                <h4>Sapca</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>


                </div>
                <p>$40.00</p>
            </div>
            <h2 class="title">Ultimele Produse</h2>


            <div class="row">
                <div class="col4">
                    <img src="imagini/poza8.jfif" alt="">
                    <h4>Geaca Primavara </h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>


                    </div>
                    <p>$40.00</p>
                </div>
                <div class="col4">
                    <img src="imagini/poza9.jfif" alt="">
                    <h4>Moto style</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>


                    </div>
                    <p>$40.00</p>
                </div>
                <div class="col4">
                    <img src="imagini/poza11.jfif" alt="">
                    <h4>Geaca rosie</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>


                    </div>
                    <p>$40.00</p>
                </div>
                <div class="col4">
                    <img src="imagini/poza12.jfif" alt="">
                    <h4>Geaca Fosforescenta</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>


                    </div>
                    <p>$40.00</p>
                </div>
                <div class="row">
                    <div class="col4">
                        <img src="imagini/poza13.jfif" alt="">
                        <h4>Ceas</h4>
                        <div class="rating">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>


                        </div>
                        <p>$40.00</p>
                    </div>
                    <div class="col4">
                        <img src="imagini/poza14.jfif" alt="">
                        <h4>Ceas</h4>
                        <div class="rating">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>


                        </div>
                        <p>$40.00</p>
                    </div>
                    <div class="col4">
                        <img src="imagini/poza15.jfif" alt="">
                        <h4>Ceas</h4>
                        <div class="rating">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>


                        </div>
                        <p>$40.00</p>
                    </div>
                    <div class="col4">
                        <img src="imagini/poza16.jfif" alt="">
                        <h4>Ceas </h4>
                        <div class="rating">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>


                        </div>
                        <p>$40.00</p>
                    </div>
                </div>






            </div>
            <!--------------Brands-->
            <div class="brenduri">
                <div class="big-container">
                    <div class="row">
                        <div class="col5">
                            <img src="imagini/logo-godrej.png">
                            <img src="imagini/logo-oppo.png">
                            <img src="imagini/logo-coca-cola.png">
                            <img src="imagini/logo-philips.png">
                            <img src="imagini/logo-paypal.png">
                        </div>
                    </div>
                </div>
            </div>

            <!-----js for toggle menu------>
        </div>
    </div>
    <?php
    require_once "./footer.php";
    ?>
    <script>
        var MenuItems = document.getElementById("MenuItems");
        MenuItems.style.maxHeight = "0px";

        function menutoggle() {
            if (MenuItems.style.maxHeight = "0px") {
                MenuItems.style.maxHeight = "200px";
            } else {
                MenuItems.style.maxHeight = "0px";
            }
        }
    </script>

</body>

</html>