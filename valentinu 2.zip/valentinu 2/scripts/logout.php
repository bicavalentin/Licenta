<?php

if(isset($_POST['submit'])){
    require_once(__DIR__.'/../utils/login_delegator.php');
    $loginDelegator = new LoginDelegator(new Validator);
    $loginDelegator->logout();
    header('location: ./../index.php');
    exit();
}