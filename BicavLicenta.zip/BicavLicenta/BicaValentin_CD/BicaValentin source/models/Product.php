<?php

class Product{
    public $id;
    public $name;
    public $price;
    public $images_path;
}





