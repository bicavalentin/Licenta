<?php

class Role{
    public $id;
    public $name;
}






