<?php

class Cart{
    public $id;
    public $user_id;
    public $user;
    public $product_id;
    public $product;
    public $bought_quantity;
    public $price;
    public $status;
}





