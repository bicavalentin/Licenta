<?php

class User{
    public $id;
    public $name;
    public $email;
    public $password;
    public $role_id;
    public $role;
}





