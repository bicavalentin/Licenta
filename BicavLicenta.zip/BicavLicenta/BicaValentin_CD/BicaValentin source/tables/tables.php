<?php
require_once(__DIR__."/products_details_table.php");
require_once(__DIR__."/products_table.php");
require_once(__DIR__."/users_table.php");
require_once(__DIR__."/roles_table.php");
require_once(__DIR__."/cart_table.php");
require_once(__DIR__."/sizes_table.php");

$tables = [
    "users_table" => UserTable::getInstance(),
    "roles_table" => RoleTable::getInstance(),
    "products_details_table" => ProductDetailsTable::getInstance(),
    "products_table" => ProductTable::getInstance(),
    "sizes_table" => SizeTable::getInstance(),
    "cart_table" => CartTable::getInstance(),
];




