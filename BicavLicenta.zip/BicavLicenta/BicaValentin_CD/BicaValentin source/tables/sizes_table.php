<?php

require_once(__DIR__.'/../utils/db_connector.php');

class SizeTable
{
    private static ?SizeTable $instance = null;

    private $conn;

    private function __construct()
    {
        $this->conn = DatabaseConnection::getInstance()->getConnection();
    }

    public static function getInstance()
    {
        if(!self::$instance)
            self::$instance = new SizeTable();
        return self::$instance;
    }

    public function getQueryErrors(){
        return $this->conn->error;
    }

    public function addSize($size){
        $sql= "INSERT INTO sizes(`name`) VALUES('$size->name')";
        $this->conn->query($sql);
    }

    public function deleteSize($id){
        $sql = "DELETE FROM sizes where `id` = '$id'";
        $this->conn->query($sql);
    }

    public function getAllSizes(){
        $sql = "SELECT * FROM `sizes`";
        return $this->conn->query($sql);
    }
}