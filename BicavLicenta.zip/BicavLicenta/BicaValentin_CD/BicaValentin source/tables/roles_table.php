<?php
require_once(__DIR__.'/../utils/db_connector.php');

class RoleTable
{
    private static ?RoleTable $instance = null;

    private $conn;

    private function __construct()
    {
        $this->conn = DatabaseConnection::getInstance()->getConnection();
    }

    public static function getInstance()
    {
        if(!self::$instance)
            self::$instance = new RoleTable();
        return self::$instance;
    }

    public function getQueryErrors(){
        return $this->conn->error;
    }

    public function addRole($role){
        $sql= "INSERT INTO roles(`name`) VALUES('$role->name')";
    
        $this->conn->query($sql);
    }

    public function deleteRole($id){
        $sql = "DELETE FROM roles where `id` = '$id'";
        $this->conn->query($sql);
    }

    public function getAllRoles(){
        $sql = "SELECT * FROM `roles`";
        return $this->conn->query($sql);
    }    
}