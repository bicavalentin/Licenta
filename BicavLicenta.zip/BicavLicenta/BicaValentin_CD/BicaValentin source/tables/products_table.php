<?php
require_once(__DIR__.'/../utils/db_connector.php');

class ProductTable
{
    private static ?ProductTable $instance = null;

    private $conn;

    private function __construct()
    {
        $this->conn = DatabaseConnection::getInstance()->getConnection();
    }

    public static function getInstance()
    {
        if(!self::$instance)
            self::$instance = new ProductTable();
        return self::$instance;
    }

    public function getQueryErrors(){
        return $this->conn->error;
    }

    public function addProduct($product){
        $sql= "INSERT INTO products(`name`,`price`,`images_path`) 
        VALUES('$product->name','$product->price', '$product->images_path')";
    
        $this->conn->query($sql);
    }

    public function updateProduct($id, $product){
        $sql ="UPDATE products SET `name` = '$product->name', 
                                `price` =  '$product->price',
                                `images_path` =  '$product->images_path'
                                WHERE `id`= '$id'";
        
        $this->conn->query($sql);
    }

    public function deleteProduct($id){
        $sql = "DELETE FROM products where `id` = '$id'";
        $this->conn->query($sql);
    }

    public function getAllProducts(){
        $sql = "SELECT * FROM `products_details` 
                    INNER JOIN `products` ON `products_details`.`product_id` = `product`.`id`
                    INNER JOIN `sizes` ON `products_details`.`size_id` = `sizes`.`id`";
        return $this->conn->query($sql);
    }
}