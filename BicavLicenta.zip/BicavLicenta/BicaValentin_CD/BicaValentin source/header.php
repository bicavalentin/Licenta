<?php 
session_start();
?>
<div class="container">
    <div class="navbar">
        <div class="logo">
            <a href="./index.php" ><img src="./imagini/logo.jpeg" width="155px"></a>
        </div>
        <nav>
            <ul id="MenuItems">
                <li><a href="./index.php">Acasa</a></li>
                <li><a href="./products.php">Produse</a></li>
                <li><a href="#">Despre</a></li>
                <li><a href="#">Contact</a></li>
                <?php 
                    if ($_SESSION["logged_in"] == false) {
                        echo '<li><a href="./account.php">Login</a></li>';
                    }
                    else{
                        echo '<li>
                        <form action="./scripts/logout.php" method="post">
                             <button type="submit" name="submit"> Logout </button>
                        </form>
                        </li>';
                    }
                ?>
            </ul>
        </nav>
        <?php 
            if ($_SESSION["logged_in"] == true) {
                echo ' <a href="./cart.php">
                    <img src="imagini/cart.png" width="30px" height="30px">
                </a>';
            }                
        ?>

    </div>
</div>