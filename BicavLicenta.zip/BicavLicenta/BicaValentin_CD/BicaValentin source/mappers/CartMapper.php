<?php

require_once(__DIR__."/../models/Cart.php");

class CartMapper{
    public static function map($data){
        $product = new Cart();
        $product->id = $data['id'] ?? null;
        $product->product_id = $data['product_id'];
        $product->user_id = $data['user_id'];
        $product->bought_quantity = $data['bought_quantity'];
        $product->price = $data['price'];
        $product->status = $data['status'];
        return $cart;
    }
}












