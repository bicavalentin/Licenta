<?php

require_once(__DIR__."/../models/Size.php");

class SizeMapper{
    public static function map($data){
        $size = new Size();
        $size->id = $data['id'] ?? null;
        $size->name = $data['name'];
        return $size;
    }
}







