<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="Style.css">
    <title>Toate Produsele</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

</head>

<body>

    <?php
    require_once "./header.php";
    ?>
    <!------Cart items details-------->
    <div class="small-container cart-page">
        <table>
            <tr>
                <th>Produs</th>
                <th>Cantitate</th>
                <th>Subtotal</th>
            </tr>
            <tr>
                <td>
                    <div class="cart-info">
                        <img src="imagini/nike1.webp" width="100px">
                        <div>
                            <p>Red Tshirt</p>
                            <small>Pret:$50.00</small>
                            <br>
                            <a href="">Remove</a>
                        </div>
                    </div>
                </td>

                <td><input type="number" value="1"></td>
                <td>$50.00</td>
            </tr>
            <tr>
                <td>
                    <div class="cart-info">
                        <img src="imagini/hanorac.webp" width="100px">
                        <div>
                            <p>Hanorac</p>
                            <small>Pret:$30.00</small>
                            <br>
                            <a href="">Remove</a>
                        </div>
                    </div>
                </td>

                <td><input type="number" value="1"></td>
                <td>$30.00</td>
            </tr>
            <tr>
                <td>
                    <div class="cart-info">
                        <img src="imagini/poza13.jfif" width="100px">
                        <div>
                            <p>Red Tshirt</p>
                            <small>Pret:$150.00</small>
                            <br>
                            <a href="">Remove</a>
                        </div>
                    </div>
                </td>

                <td><input type="number" value="1"></td>
                <td>$150.00</td>
            </tr>
        </table>

        <div class="total-price">
            <table>
                <tr>
                    <td>Subtotal</td>
                    <td>$200.00</td>
                </tr>
                <tr>
                    <td>Tax</td>
                    <td>$30.00</td>
                </tr>
                <tr>
                    <td>Total</td>
                    <td>$230.00</td>
                </tr>
            </table>
        </div>

    </div>

    <?php
    require_once "./footer.php";
    ?>
</body>

</html>