<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if(isset($_POST['submit'])){
    require_once(__DIR__.'/../tables/tables.php');
    require_once(__DIR__."/../mappers/SizeMapper.php");
    require_once(__DIR__."/../mappers/ProductMapper.php");
    require_once(__DIR__."/../mappers/ProductDetailsMapper.php");

    $product = ProductMapper::map($_POST);
    $tables["products_table"]->addProduct($product);
    $id = ProductMapper::map(
                $tables["products_table"]->getLatestProduct()
                                        ->fetch_assoc()
            )->id;
 
    foreach ($_POST["sizes"] as $key => $value) {
        $temp = [
            "size_id" => $value,
            "product_id" => $id,
            "quantity" => $_POST["quantity"]
        ];
        $product_details = ProductDetailsMapper::map($temp);
        $tables["products_details_table"]->addProduct($product_details);
    }
    header('location: ./../dashboard.php');
    exit();
}
header('location: ./../404.php');
exit();