<?php
if(isset($_POST['submit'])){
    require_once(__DIR__.'/../tables/tables.php');
    $tables["users_table"]->deleteUser($_POST["user_id"]);
    header('location: ./../dashboard.php');
    exit();
}
header('location: ./../404.php');
exit();