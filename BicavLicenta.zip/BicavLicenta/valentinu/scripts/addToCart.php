<?php
if(isset($_POST['submit'])){
    require_once(__DIR__.'/../tables/tables.php');
    require_once(__DIR__."/../mappers/CartMapper.php");
    session_start();
    $data = $_POST;
    $data["user_id"] = $_SESSION["id"];
    $data["status"] = "pending";
    $cart_item = CartMapper::map($data);
    $tables["cart_table"]->addToCart($cart_item);
    header('location: ./../cart.php');
    exit();
}
header('location: ./../404.php');
exit();