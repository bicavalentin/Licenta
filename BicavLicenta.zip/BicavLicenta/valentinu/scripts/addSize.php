<?php
if(isset($_POST['submit'])){
    require_once(__DIR__.'/../tables/tables.php');
    require_once(__DIR__."/../mappers/SizeMapper.php");
    $size = SizeMapper::map($_POST);
    $tables["sizes_table"]->addSize($size);
    header('location: ./../dashboard.php');
    exit();
}
header('location: ./../404.php');
exit();