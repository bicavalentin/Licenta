<?php
if(isset($_POST['submit'])){
    require_once(__DIR__.'/../tables/tables.php');
    session_start();
    $tables["cart_table"]->confirmOrder($_SESSION["id"]);
    header('location: ./../confirm.php');
    exit();
}
header('location: ./../404.php');
exit();