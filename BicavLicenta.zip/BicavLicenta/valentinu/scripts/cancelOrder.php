<?php
if(isset($_POST['submit'])){
    require_once(__DIR__.'/../tables/tables.php');
    session_start();
    $tables["cart_table"]->cancelOrder($_SESSION["id"]);
    header('location: ./../cart.php');
    exit();
}
header('location: ./../404.php');
exit();