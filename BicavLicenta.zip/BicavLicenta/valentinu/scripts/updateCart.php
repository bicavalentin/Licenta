<?php
if(isset($_POST['submit'])){
    require_once(__DIR__.'/../tables/tables.php');
    require_once(__DIR__."/../mappers/CartMapper.php");
    session_start();
    $data = $_POST;
    $cart_item = CartMapper::map($data);
    $tables["cart_table"]->updateCartProduct($data["cart_id"],$cart_item);
    header('location: ./../cart.php');
    exit();
}
header('location: ./../404.php');
exit();