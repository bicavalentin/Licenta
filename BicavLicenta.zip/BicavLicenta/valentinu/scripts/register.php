<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if(isset($_POST['submit'])){
    $rules = [
        'name' => [
            'required' => true,
            'min_len' => 3,
            'max_len' => 20,
        ],
        'email' => [
            'required' => true,
            'email' => true,
        ],
        'password' => [
            'required' => true,
            'min_len' => 6,
            'max_len' => 20,
        ]
    ];

    $register_data = [
        "name" => $_POST['username'],
        "email" => $_POST['email'],
        "password" => $_POST['password']
    ];

    require_once(__DIR__."/../utils/validator.php");
    $v = new Validator();
    $v->validate($register_data, $rules);
    if($v->hasErrors()){
        print_r($v->getErrors());
        die;
    }
 
    require_once(__DIR__."/../tables/tables.php");
    require_once(__DIR__."/../mappers/UserMapper.php");
    $register_data["role_id"] = 2;
    $register_data["password"] = hash("sha256",$register_data["password"]);
    $user = UserMapper::map($register_data);
   
    if ($tables["users_table"]->getUserByEmail($user->email)->fetch_assoc() != null) {
        echo "Email deja folosit";
        die;
    }

    $tables["users_table"]->addUser($user);
    header('location: ./../account.php');
    exit();
}
header('location: ./../404.php');
exit();