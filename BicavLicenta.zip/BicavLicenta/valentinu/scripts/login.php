<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if(isset($_POST['submit'])){
    require_once(__DIR__.'/../utils/login_delegator.php');
    $rules = [
        'email' => [
            'required' => true,
            'email'=> true,
        ],
        'password' => [
            'required' => true,
            'min_len' => 6,
            'max_len' => 20,
        ]
    ];

    $login_data = [
        "email" => $_POST['email'],
        "password" => $_POST['password']
    ];

    $loginDelegator = new LoginDelegator(new Validator, $rules);
    $loginDelegator->setData($login_data);
    try{
        $errors = $loginDelegator->login();
    }catch(Exception $e){
        $errors = [
            'error' => [$e->getMessage()],
        ];
    }
    
    if(isset($errors)){
        header('location: ./../index.php?'.http_build_query($errors));
        exit();
    }   
    header('location: ./../products.php');
    exit();

}
header('location: ./../404.php');
exit();