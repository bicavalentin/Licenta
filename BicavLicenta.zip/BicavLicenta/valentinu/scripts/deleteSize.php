<?php
if(isset($_POST['submit'])){
    require_once(__DIR__.'/../tables/tables.php');
    $tables["sizes_table"]->deleteSize($_POST["size_id"]);
    header('location: ./../dashboard.php');
    exit();
}
header('location: ./../404.php');
exit();