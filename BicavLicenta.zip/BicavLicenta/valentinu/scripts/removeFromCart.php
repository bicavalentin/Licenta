<?php
if(isset($_POST['submit'])){
    require_once(__DIR__.'/../tables/tables.php');
    $tables["cart_table"]->removeFromCart($_POST["cart_id"]);
    header('location: ./../cart.php');
    exit();
}
header('location: ./../404.php');
exit();