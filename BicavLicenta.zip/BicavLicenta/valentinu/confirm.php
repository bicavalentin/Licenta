<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="./Style.css">
    <title>Toate Produsele</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

</head>

<body>

    <?php
    require_once "./header.php";
    ?>
    <!--------- acount page------------>
   <h1>Comanda a fost procesata cu succes</h1>

    <?php
    require_once "./footer.php";
    ?>


   
   

</body>

</html>