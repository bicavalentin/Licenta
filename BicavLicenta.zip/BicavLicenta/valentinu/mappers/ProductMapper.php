<?php

require_once(__DIR__."/../models/Product.php");

class ProductMapper{
    public static function map($data){
        $product = new Product();
        $product->id = $data['id'] ?? null;
        $product->name = $data['product_name'];
        $product->price = $data['price'];
        $product->description= $data['product_description'];
        $product->images_path = $data['images_path'];
        return $product;
    }
}

