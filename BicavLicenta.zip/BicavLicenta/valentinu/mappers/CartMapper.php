<?php

require_once(__DIR__."/../models/Cart.php");

class CartMapper{
    public static function map($data){
        $cart = new Cart();
        $cart->id = $data['id'] ?? null;
        $cart->product_id = $data['product_id'];
        $cart->user_id = $data['user_id'];
        $cart->bought_quantity = $data['bought_quantity'];
        $cart->price = $data['price'];
        $cart->status = $data['status'];
        return $cart;
    }
}

