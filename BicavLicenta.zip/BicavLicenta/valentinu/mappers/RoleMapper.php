<?php

require_once(__DIR__."/../models/Role.php");

class RoleMapper{
    public static function map($data){
        $role = new Role();
        $role->id = $data['id'] ?? null;
        $role->name = $data['role_name'];
        return $role;
    }
}

