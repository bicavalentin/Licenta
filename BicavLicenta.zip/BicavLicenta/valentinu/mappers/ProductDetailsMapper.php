<?php

require_once(__DIR__."/../models/ProductDetails.php");

class ProductDetailsMapper{
    public static function map($data){
        $product = new ProductDetails();
        $product->id = $data['id'] ?? null;
        $product->product_id = $data['product_id'];
        $product->size_id = $data['size_id'];
        $product->quantity = $data['quantity'];
        return $product;
    }
}

