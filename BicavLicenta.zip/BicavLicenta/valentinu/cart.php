<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="Style.css">
    <title>Cos</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

</head>

<body>

    <?php
    require_once "./header.php";

    require_once __DIR__ . "/tables/tables.php";
    require_once __DIR__ . "/mappers/CartMapper.php";
    require_once __DIR__ . "/mappers/ProductMapper.php";

    ?>
    <!------Cart items details-------->
    <div class="small-container cart-page">
        <table>
            <tr>
                <th>Produs</th>
                <th>Cantitate</th>
                <th>Subtotal</th>
            </tr>
            <tr>
                <?php
                ini_set('display_errors', 1);
                ini_set('display_startup_errors', 1);
                error_reporting(E_ALL);
                    $sum = 0;
                    foreach ($tables["cart_table"]->getAllItemsFromCart($_SESSION["id"])->fetch_all(MYSQLI_ASSOC) as $key => $value) {
                        $cart = CartMapper::map($value);
                        $product = ProductMapper::map($value);
                        $img = explode(";",$product->images_path)[0];
                        $subTotal = $cart->price * $cart->bought_quantity;
                        echo "
                                <tr>
                                    <td>
                                        <div class='cart-info'>
                                            <img src='$img' width='100px'>
                                            <div>
                                                <p>$product->name</p>
                                                <small>Pret: $ $cart->price</small>
                                                <br>
                                                <form action='./scripts/removeFromCart.php' method='post'>
                                                    <input type='hidden' name='cart_id' value='$cart->id'>
                                                    <button type='submit' class='btn' name='submit'>Sterge</button>
                                                </form>
                                            </div>
                                        </div>
                                    </td>
            
                            <td>
                                <form action='./scripts/updateCart.php' method='post'>
                                    <input type='hidden' name='cart_id' value='$cart->id'>
                                    <input type='number' min='1' name='bought_quantity' value='$cart->bought_quantity' style= 'width:60px;'>
                                    <button type='submit' name='submit' class='btn' style='width:120px;'>Modifica</button>
                                </form>
                            </td>
                            <td>$ $subTotal</td>                                
                            </tr>
                            ";
                        $sum += $subTotal ;
                    }
                ?>

            </tr>

        </table>

        <div class="total-price">
            <table>
                <tr>
                    <td>Subtotal</td>
                    <td>$ <?php echo $sum; ?></td>
                </tr>
                <tr>
                    <td>Tax</td>
                    <td>$ 10.00</td>
                </tr>
                <tr>
                    <td>Total</td>
                    <td>$ <?php echo $sum + 10 ; ?> </td>
                </tr>
            </table>

        </div>
        <form method="POST" action="./scripts/cancelOrder.php">
                <input type="submit" class="btn" name="submit" value="Anuleaza">
            </form>

            <form method="POST" action="./scripts/confirmOrder.php">
                <input type="submit" class="btn" name="submit" value="Confirma">
            </form>

    </div>

    <br><br><br><br><br><br><br><br><br><br><br>
    <?php
    require_once "./footer.php";
    ?>
</body>

</html>