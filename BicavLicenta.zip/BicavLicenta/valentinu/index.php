<?php
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="Style.css">
    <title>Cumparaturi Online</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

</head>

<body>
    <div class="header">
        <div class="container">
            <?php
            require_once "./header.php";
            ?>

            <div class="row">
                <div class="col2">
                    <h1>Uita de griji si fa-ti cumparaturile <br>online alaturi de Emag si Carrefour</h1>
                    <p>Uita de griji Uita de griji Uita de griji Uita <br>de griji Uita de griji Uit Uita de griji </p>
                    <a href="./products.php" class="btn">Exploreaza acum</a>
                </div>
                <div class="col2">
                    <img src="imagini/image1.png">
                </div>
            </div>
        </div>
    </div>

    <!------ produse----->

    <div class="small-container">
        <h2 class="title">Articole Recomandate</h2>
        <div class="row">
            <?php
                require_once(__DIR__.'/tables/tables.php');
                require_once(__DIR__."/mappers/ProductMapper.php");
                foreach ($tables["products_table"]->getTopProducts()->fetch_all(MYSQLI_ASSOC) as $key => $value) {
                    $product = ProductMapper::map($value);
                    $img = explode(";",$product->images_path)[0];
                    echo "
                    <div class='col4'>
                        <img src='$img' alt='placeholder'>
                        <h4>$product->name</h4>
                        <div class='rating'>
                            <i class='fa fa-star'></i>
                            <i class='fa fa-star'></i>
                            <i class='fa fa-star'></i>
                        </div>
                        <p>$ $product->price</p>
                    </div>";
                }
            ?>
        </div>

        <h2 class="title">Ultimele Produse</h2>


            <div class="row">
            <?php
                foreach ($tables["products_table"]->getLatestProducts(12)->fetch_all(MYSQLI_ASSOC) as $key => $value) {
                    $product = ProductMapper::map($value);
                    $img = explode(";",$product->images_path)[0];
                    echo "
                    <div class='col4'>
                        <img src='$img' alt='placeholder'>
                        <h4>$product->name</h4>
                        <div class='rating'>
                            <i class='fa fa-star'></i>
                            <i class='fa fa-star'></i>
                            <i class='fa fa-star'></i>
                        </div>
                        <p>$ $product->price</p>
                    </div>";
                }
            ?>
            </div>
            <!--------------Brands-->
            <div class="brenduri">
                <div class="big-container">
                    <div class="row">
                        <div class="col5">
                            <img src="imagini/logo-godrej.png">
                            <img src="imagini/logo-oppo.png">
                            <img src="imagini/logo-coca-cola.png">
                            <img src="imagini/logo-philips.png">
                            <img src="imagini/logo-paypal.png">
                        </div>
                    </div>
                </div>
            </div>
    </div>
    <?php
    require_once "./footer.php";
    ?>
    <script>
        var MenuItems = document.getElementById("MenuItems");
        MenuItems.style.maxHeight = "0px";

        function menutoggle() {
            if (MenuItems.style.maxHeight = "0px") {
                MenuItems.style.maxHeight = "200px";
            } else {
                MenuItems.style.maxHeight = "0px";
            }
        }
    </script>

</body>

</html>