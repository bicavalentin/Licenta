<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="Style.css">
    <title>Toate Produsele</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

</head>

<body>

    <?php
    require_once "./header.php";

    if ($_SESSION["logged_in"] != true) {
        header("location: ./account.php");
        exit();
    }

    require_once __DIR__ . "/tables/tables.php";
    require_once __DIR__ . "/mappers/ProductDetailsMapper.php";
    require_once __DIR__ . "/mappers/ProductMapper.php";
    $product_id = $_GET["product_id"];
    $productWithSizes = $tables["products_details_table"]->getProductById($product_id)->fetch_all(MYSQLI_ASSOC);
    $product = ProductMapper::map($productWithSizes[0]);
    ?>
    <!-----Single Product details------->
    <div class="small-container single-product">
        <div class="row">
            <div class="col2">
                <?php
                    $imgs = explode(";", $product->images_path);
                    $main_img = $imgs[0];
                    echo "
                        <img src='$main_img' width='100%' id='ProductImg'>
                    ";
                    echo "
                    <div class='small-img-row'>";
                    foreach ($imgs as $key => $value) {
                        echo "<div class='small-img-col'>
                        <img src='$value' width='100%' class='small-img'>
                        </div>";
                    }
                    echo "</div>";
                ?>

            </div>
            <div class="col2">
                <h1><?php echo $product->name ?> </h1>
                <h4><?php echo $product->price ?> </h4>
                <form action="./scripts/addToCart.php" method="POST">

                <select name="size_id">
                    <option>Select Size</option>
                    <?php
                    foreach ($productWithSizes as $key => $value) {
                        $size_id = $value["size_id"];
                        $size_name = $value["size_name"];
                        echo " <option value='$size_id'>$size_name</option>";
                    }
                    ?>

                </select>
                <br>
                <input type="hidden" name="product_id" value="<?php echo $product_id?>" >
                <input type="hidden" name="price" value="<?php echo $product->price?>" >
                <input type="number" name="bought_quantity" value="1">
                <input type="submit" name="submit" class="btn" style="width: 100px;" value="Pune in cos">
                </form>
                <h3>Detalii produs</h3>
                <p><?php echo $product->description ?> </p>

            </div>
        </div>
    </div>

    <div class="small-container">
        <div class="row row-2">
            <h2>Produse Recomandate</h2>
        </div>
    </div>

    <div class="small-container">

        <div class="row row-2">

            <?php
                foreach ($tables["products_table"]->getRandomProducts()->fetch_all(MYSQLI_ASSOC) as $key => $value) {
                    $product = ProductMapper::map($value);
                    $img = explode(";",$product->images_path)[0];
                    echo "
                        <div class='col4'>
                        <a href='products-details.php?product_id=$product->id'>
                        <img src='$img' alt='placeholder'/>
                            <h4>$product->name</h4>
                            <div class='rating'>
                                <i class='fa fa-star'></i>
                                <i class='fa fa-star'></i>
                                <i class='fa fa-star'></i>
                            </div>
                            <p>$ $product->price</p>
                            </a>
                        </div>
                    ";
                }
            ?>
        </div>

    </div>

            <?php
            require_once "./footer.php";
            ?>
            <!-----js for toggle menu------>

            <script>
                var MenuItems = document.getElementById("MenuItems");
                MenuItems.style.maxHeight = "0px";

                function menutoggle() {
                    if (MenuItems.style.maxHeight = "0px") {
                        MenuItems.style.maxHeight = "200px";
                    } else {
                        MenuItems.style.maxHeight = "0px";
                    }
                }
            </script>

            <!-----js for product gallery------>

            <script>
                var ProductImg = document.getElementById("ProductImg");
                var SmallImg = document.getElementsByClassName("small-img");
                SmallImg[0].onclick = function() {
                    ProductImg.src = SmallImg[0].src;
                }

                SmallImg[1].onclick = function() {
                    ProductImg.src = SmallImg[1].src;
                }

                SmallImg[2].onclick = function() {
                    ProductImg.src = SmallImg[2].src;
                }

                SmallImg[3].onclick = function() {
                    ProductImg.src = SmallImg[3].src;
                }
            </script>


</body>

</html>