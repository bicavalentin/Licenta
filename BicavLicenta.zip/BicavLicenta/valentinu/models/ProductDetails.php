<?php

class ProductDetails{
    public $id;
    public $product_id;
    public $product;
    public $size_id;
    public $size;
    public $quantity;
}
