<?php

class Product{
    public $id;
    public $name;
    public $description;
    public $price;
    public $images_path;
}
