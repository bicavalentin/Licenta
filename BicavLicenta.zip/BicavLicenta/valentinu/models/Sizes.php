<?php

class Size{
    public $id;
    public $name;
}
