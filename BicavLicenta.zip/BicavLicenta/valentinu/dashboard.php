<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="./Style.css">
    <title>Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

</head>
<?php
session_start();
if ($_SESSION["is_admin"] != true) {
    header("location: ./index.php");
    exit();
}

require_once __DIR__ . "/tables/tables.php";
require_once __DIR__ . "/mappers/CartMapper.php";
require_once __DIR__ . "/mappers/RoleMapper.php";
require_once __DIR__ . "/mappers/SizeMapper.php";
require_once __DIR__ . "/mappers/UserMapper.php";
require_once __DIR__ . "/mappers/ProductDetailsMapper.php";
require_once __DIR__ . "/mappers/ProductMapper.php";
?>

<body>

    <?php
    require_once "./header.php";
    ?>
    <div class="account-page">
        <div class="container">
        <section class="row">
                <h2>Roluri</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Nr Crt</th>
                            <th>Nume</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($tables["roles_table"]->getAllRoles()->fetch_all(MYSQLI_ASSOC) as $key => $value) {
                            $role = RoleMapper::map($value);
                            echo "
                                    <tr>
                                        <td>$role->id</td>
                                        <td>$role->name</td>
                                    </tr>
                                ";
                        }
                        ?>
                    </tbody>
                </table>
            </section>

            <br />
            <hr /><br />

            <section class="row">
                <h2>Utilizatori</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Nr Crt</th>
                            <th>Nume</th>
                            <th>Email</th>
                            <th>Rol</th>
                            <th>Actiuni</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($tables["users_table"]->getAllUsers()->fetch_all(MYSQLI_ASSOC) as $key => $value) {
                            $user = UserMapper::map($value);
                            $role = RoleMapper::map($value);
                            echo "
                                    <tr>
                                        <td>$user->id</td>
                                        <td>$user->name</td>
                                        <td>$user->email</td>
                                        <td>$role->name</td>
                                        <td>
                                            <form action='./scripts/deleteUser.php' method='post'>
                                                <input type='hidden' name='user_id' value='$user->id'>
                                                <button type='submit' name='submit'>Sterge</button>
                                            </form>
                                        </td>
                                    </tr>
                                ";
                        }
                        ?>
                    </tbody>
                </table>
            </section>

            <br />
            <hr /><br />

            <section class="row">
                <h2>Marimi</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Nr Crt</th>
                            <th>Marime</th>
                            <th>Actiuni</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($tables["sizes_table"]->getAllSizes()->fetch_all(MYSQLI_ASSOC) as $key => $value) {
                            $size = SizeMapper::map($value);
                            echo "
                                    <tr>
                                        <td>$size->id</td>
                                        <td>$size->name</td>
                                        <td>
                                            <form action='./scripts/deleteSize.php' method='post'>
                                                <input type='hidden' name='size_id' value='$size->id'>
                                                <button type='submit' name='submit'>Sterge</button>
                                            </form>
                                        </td>
                                    </tr>
                                ";
                        }
                        ?>
                    </tbody>
                </table>
            </section>

            <br>
            <hr /><br>

            <section class="row">
                <h2>Adauga marimi </h2>
                <form id="LoginForm" action="./scripts/addSize.php" method="post">
                    <input type="text" placeholder="Marime" name="size_name">
                    <button type="submit" name="submit" class="btn">Adauga</button>
                </form>
            </section>

            <br>
            <hr /><br>

            <section class="row">
                <h2>Produse</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Nr Crt</th>
                            <th>Nume</th>
                            <th>Pret</th>
                            <th>Marime</th>
                            <th>Cantitate</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($tables["products_details_table"]->getAllProducts()->fetch_all(MYSQLI_ASSOC) as $key => $value) {
                            $size = SizeMapper::map($value);
                            $product = ProductMapper::map($value);
                            $product_details = ProductDetailsMapper::map($value);
                            echo "
                                    <tr>
                                        <td>$product->id</td>
                                        <td>$product->name</td>
                                        <td>$product->price</td>
                                        <td>$size->name</td>
                                        <td>$product_details->quantity</td>
                                    </tr>
                                ";
                        }
                        ?>
                    </tbody>
                </table>
            </section>

            <br>
            <hr /><br>

            <section class="row">
                <h2>Adauga produse</h2>
                <form id="LoginForm" action="./scripts/addProduct.php" method="post">
                    <input type="text" placeholder="Produs" name="product_name">
                    <input type="text" placeholder="Descriere" name="product_description">
                    <input type="text" placeholder="Pret" name="price">
                    <textarea name="images_path">SEPARATE CU ;</textarea>
                    <br><br>
                    <select multiple name="sizes[]" style="width:350px">
                        <option value="">Alege</option>
                        <?php
                        foreach ($tables["sizes_table"]->getAllSizes()->fetch_all(MYSQLI_ASSOC) as $key => $value) {
                            $size = SizeMapper::map($value);
                            echo "
                                        <option value='$size->id'>$size->name</option>
                                    ";
                        }
                        ?>
                    </select>
                    <input type="number" placeholder="Cantitate" name="quantity" min="1">
                    <button type="submit" name="submit" class="btn">Adauga</button>
                </form>
            </section>

            <br>
            <hr /><br>

            <section class="row">
                <h2>Vanzari</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Nr Crt</th>
                            <th>Nume Produs</th>
                            <th>Pret</th>
                            <th>Utilizator</th>
                            <th>Cantitate</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($tables["cart_table"]->getAllItemsFromCartAdmin()->fetch_all(MYSQLI_ASSOC) as $key => $value) {
                            $user = UserMapper::map($value);
                            $product = ProductMapper::map($value);
                            $cart = CartMapper::map($value);
                            echo "
                                    <tr>
                                        <td>$product->id</td>
                                        <td>$product->name</td>
                                        <td>$product->price</td>
                                        <td>$user->email</td>
                                        <td>$cart->bought_quantity</td>
                                        <td>$cart->status</td>
                                    </tr>
                                ";
                        }
                        ?>
                    </tbody>
                </table>
            </section>
            <hr />


        </div>
    </div>

    <?php
    require_once "./footer.php";
    ?>
</body>

</html>