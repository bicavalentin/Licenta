<?php

class DatabaseConnection
{
    private static ?DatabaseConnection $instance = null;
    private $conn;

    private $host = "localhost";
    private $user = "root";
    private $passwd = "";
    private $db = "db_magazin_online";

    private function __construct()
    {
        $this->conn = new mysqli($this->host, $this->user, $this->passwd, $this->db);
    }

    public static function getInstance()
    {
        if(!self::$instance)
            self::$instance = new DatabaseConnection();
        return self::$instance;
    }

    public function getConnection()
    {
        return $this->conn;
    }
}

$singletonInstance = DatabaseConnection::getInstance();

$conn = $singletonInstance->getConnection();
if($conn->connect_error)
    die("Connection failed: " . $conn->connect_error);

// echo "Singleton connected successfuly";

?>