<?php

require_once(__DIR__.'/../utils/db_connector.php');

class ProductDetailsTable
{
    private static ?ProductDetailsTable $instance = null;

    private $conn;

    private function __construct()
    {
        $this->conn = DatabaseConnection::getInstance()->getConnection();
    }

    public static function getInstance()
    {
        if(!self::$instance)
            self::$instance = new ProductDetailsTable();
        return self::$instance;
    }

    public function getQueryErrors(){
        return $this->conn->error;
    }

    public function addProduct($product){
        $sql= "INSERT INTO products_details(`product_id`,`quantity`,`size_id`)
                VALUES('$product->product_id','$product->quantity', '$product->size_id')";
    
        $this->conn->query($sql);
    }

    public function deleteProduct($id){
        $sql = "DELETE FROM products_details where `id` = '$id'";
        $this->conn->query($sql);
    }

    public function getAllProducts(){
        $sql = "SELECT * FROM `products_details` 
            INNER JOIN `products` ON `products_details`.`product_id` = `products`.`id`
            INNER JOIN `sizes` ON `products_details`.`size_id` = `sizes`.`id`";
        return $this->conn->query($sql);
    }

    public function getProductById($product_id){
        $sql = "SELECT * FROM `products_details` 
            INNER JOIN `products` ON `products_details`.`product_id` = `products`.`id`
            INNER JOIN `sizes` ON `products_details`.`size_id` = `sizes`.`id`
            WHERE `products_details`.`product_id` = '$product_id'";
        return $this->conn->query($sql);
    }
    
}