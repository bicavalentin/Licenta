<?php

require_once(__DIR__.'/../utils/db_connector.php');

class ProductTable
{
    private static ?ProductTable $instance = null;

    private $conn;

    private function __construct()
    {
        $this->conn = DatabaseConnection::getInstance()->getConnection();
    }

    public static function getInstance()
    {
        if(!self::$instance)
            self::$instance = new ProductTable();
        return self::$instance;
    }

    public function getQueryErrors(){
        return $this->conn->error;
    }

    public function getRandomProducts($limit = 4){
        $sql = "SELECT * FROM `products` ORDER BY RAND() DESC LIMIT $limit";
        return $this->conn->query($sql);
    }

    public function getTopProducts($limit = 4){
        $sql = "SELECT * FROM `products` ORDER BY `price` DESC LIMIT $limit";
        return $this->conn->query($sql);
    }

    public function getAllProductsWithoutDetails(){
        $sql = "SELECT * FROM `products`";
        return $this->conn->query($sql);
    }

    public function getLatestProducts($limit = 12){
        $sql = "SELECT * FROM `products` ORDER BY `price` DESC limit $limit";
        return $this->conn->query($sql);
    }

    public function getLatestProduct(){
        $sql = "SELECT * FROM `products` ORDER BY `id` DESC limit 1";
        return $this->conn->query($sql);
    }

    public function addProduct($product){
        $sql= "INSERT INTO products(`product_name`,`price`,`images_path`, `product_description`) 
        VALUES('$product->name','$product->price', '$product->images_path', '$product->description')";
    
        $this->conn->query($sql);
    }

    public function updateProduct($id, $product){
        $sql ="UPDATE products SET `product_name` = '$product->name', 
                                `price` =  '$product->price',
                                `product_description` =  '$product->description',
                                `images_path` =  '$product->images_path'
                                WHERE `id`= '$id'";
        
        $this->conn->query($sql);
    }

    public function deleteProduct($id){
        $sql = "DELETE FROM products where `id` = '$id'";
        $this->conn->query($sql);
    }

    public function getAllProducts(){
        $sql = "SELECT * FROM `products_details` 
            INNER JOIN `products` ON `products_details`.`product_id` = `products`.`id`
            INNER JOIN `sizes` ON `products_details`.`size_id` = `sizes`.`id`";
        return $this->conn->query($sql);
    }
}