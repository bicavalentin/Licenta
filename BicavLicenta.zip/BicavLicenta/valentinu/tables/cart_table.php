<?php

require_once(__DIR__.'/../utils/db_connector.php');

class CartTable
{
    private static ?CartTable $instance = null;

    private $conn;

    private function __construct()
    {
        $this->conn = DatabaseConnection::getInstance()->getConnection();
    }

    public static function getInstance()
    {
        if(!self::$instance)
            self::$instance = new CartTable();
        return self::$instance;
    }

    public function getQueryErrors(){
        return $this->conn->error;
    }

    public function addToCart($cart){
        $sql= "INSERT INTO cart(`user_id`,`product_id`,`bought_quantity`, `price`,`status`)
                VALUES('$cart->user_id','$cart->product_id', '$cart->bought_quantity','$cart->price','$cart->status')";
    
        $this->conn->query($sql);
    }

    public function updateCartProduct($id,$cart){
        $sql ="UPDATE cart SET `bought_quantity` =  '$cart->bought_quantity'
                                WHERE `id`= '$id'";
        
        $this->conn->query($sql);
    }

    public function removeFromCart($id){
        $sql = "DELETE FROM cart where `id` = '$id'";
        $this->conn->query($sql);
    }

    public function getAllItemsFromCart($user_id){
        $sql = "SELECT `products`.`product_name`,`products`.`images_path`,`products`.`product_description`,
                        `users`.`name`, `users`.`email`,
                        `cart`.* FROM `cart` 
                        INNER JOIN `users` ON `cart`.`user_id` = `users`.`id`
                        INNER JOIN `products` ON `cart`.`product_id` = `products`.`id`
                        WHERE `users`.`id` = '$user_id'
                        AND `cart`.`status` = 'pending'";
        return $this->conn->query($sql);
    }

    public function confirmOrder($user_id){
        $sql ="UPDATE cart SET `status` =  'confirmed' WHERE `user_id`= '$user_id' AND `status`='pending'";
        $this->conn->query($sql);
    }   

    public function cancelOrder($user_id){
        $sql ="UPDATE cart SET `status` =  'canceled' WHERE `user_id`= '$user_id' AND `status` = 'pending'";
        $this->conn->query($sql);
    }   

    public function getAllItemsFromCartAdmin(){
        $sql = "SELECT * FROM `cart` 
                        INNER JOIN `users` ON `cart`.`user_id` = `users`.`id`
                        INNER JOIN `products` ON `cart`.`product_id` = `products`.`id`";
        return $this->conn->query($sql);
    }

}