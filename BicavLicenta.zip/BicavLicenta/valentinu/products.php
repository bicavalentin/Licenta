<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="Style.css">
    <title>Toate Produsele</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

</head>

<body>
    <?php
    require_once "./header.php";
    ?>
    <!------ produse----->
    <div class="small-container">
        <div class="row row-2">
            <h2>Toate Produsele</h2>
        </div>
        <div class="row">
            <?php
                require_once(__DIR__.'/tables/tables.php');
                require_once(__DIR__."/mappers/ProductMapper.php");
                foreach ($tables["products_table"]->getAllProductsWithoutDetails()->fetch_all(MYSQLI_ASSOC) as $key => $value) {
                    $product = ProductMapper::map($value);
                    $img = explode(";",$product->images_path)[0];
                    echo "
                        <div class='col4'>
                        <a href='products-details.php?product_id=$product->id'>
                        <img src='$img' alt='placeholder'>
                            <h4>$product->name</h4>
                            <div class='rating'>
                                <i class='fa fa-star'></i>
                                <i class='fa fa-star'></i>
                                <i class='fa fa-star'></i>
                            </div>
                            <p>$ $product->price</p>
                            </a>
                        </div>
                    ";
                }
            ?>
        </div>

    </div>

                <?php
                require_once "./footer.php";
                ?>
                <!-----js for toggle menu------>

                <script>
                    var MenuItems = document.getElementById("MenuItems");
                    MenuItems.style.maxHeight = "0px";

                    function menutoggle() {
                        if (MenuItems.style.maxHeight = "0px") {
                            MenuItems.style.maxHeight = "200px";
                        } else {
                            MenuItems.style.maxHeight = "0px";
                        }
                    }
                </script>

</body>

</html>